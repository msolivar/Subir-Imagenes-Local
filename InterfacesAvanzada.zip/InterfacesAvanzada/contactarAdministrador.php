<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $categoria = $_POST['categoria'];
    $mensaje = $_POST['mensaje'];

    // Validaciones básicas
    if (empty($nombre) || empty($email) || empty($categoria) || empty($mensaje)) {
        echo "Todos los campos son obligatorios.";
        exit;
    }

    echo '<script type="text/javascript">
			alert("Mensaje Enviado.");     
			window.location="index.php";
		</script>';
}
?>