<?php
$reportes = [
    ["id" => 1, "categoria" => "Seguridad", "titulo" => "Robo en la esquina", "descripcion" => "Se reportó un robo cerca de la avenida principal.", "ubicacion" => "Centro"],
    ["id" => 2, "categoria" => "Emergencias", "titulo" => "Accidente de tránsito", "descripcion" => "Choque entre dos vehículos en la intersección.", "ubicacion" => "Avenida 4°"],
    ["id" => 3, "categoria" => "Infraestructura", "titulo" => "Farola rota", "descripcion" => "Farola sin luz en el parque central.", "ubicacion" => "Estadio Centenario"]
];

$imagenes = [
    'https://www.eluniversal.com.co/resizer/v2/FLNNWNEB3JH45JI2GANJKUHVNU.jpeg?auth=89a448ce92002d63fd62c9572197517045cf8672037cfa300359c0a4716d483d&smart=true&width=1200&height=800&quality=70',
    'https://i0.wp.com/nbi.com.co/wp-content/uploads/2020/10/accidente-de-transito-articulo-e1721281923171.jpg?fit=1199%2C627&ssl=1',
    'https://media.istockphoto.com/id/496026170/es/foto/broken-street-l%C3%A1mpara.jpg?s=1024x1024&w=is&k=20&c=ExTrjvvsx-lYoNozjaw22EwPlJMBWq294Kh-PDs8hO4=',
    'https://i0.wp.com/nbi.com.co/wp-content/uploads/2020/10/accidente-de-transito-articulo-e1721281923171.jpg?fit=1199%2C627&ssl=1'
];

function filtrarReportes($categoria, $reportes) {
    return array_filter($reportes, function($reporte) use ($categoria) {
        return $reporte["categoria"] == $categoria;
    });
}

if (isset($_GET["categoria"])) {
    $categoria = $_GET["categoria"];
    $reportes = filtrarReportes($categoria, $reportes);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="hojaEstilo.css">
    <title>gestionar Reporte</title>
</head>
<body>

    <?php  
        include('navUsuario.php');
    ?>
    <div class="container">
        <h2><center>Reporte</center></h2>

        <form action="crear_reporte.php" method="POST" enctype="multipart/form-data">
            
            <fieldset>
                <!-- <legend>Datos personales</legend> -->
                <div class="col-100">
                    <label for="titulo">Título:</label><br>
                    <input type="text" id="titulo" name="titulo" placeholder="Ingrese el titulo" required><br>
                </div>
                <div class="col-100">
                    <label for="categoriaReporte">Categoría:</label><br>
                    <select id="categoriaReporte" name="categoriaReporte" required>

                        <option value="">Seleccionar Categoria</option>
                        <option value="Seguridad">Seguridad</option>
                        <option value="Emergencias">Emergencias</option>
                        <option value="Infraestructura">Infraestructura</option>
                        <option value="salud">Salud</option>
                    </select><br>
                </div>
                <div class="col-100">
                    <label for="descripcion">Descripción:</label><br>
                    <textarea id="descripcion" name="descripcion" placeholder="Ingrese la Descripcion" required></textarea><br>
                </div>
                <div class="col-100">
                    <label for="ubicacion">Ubicacion:</label><br>
                    <input type="text" id="ubicacion" name="ubicacion" placeholder="Ingrese la ubicacion" required>
                    <button class="small" style="background-color: #007BFF;" type="submit">Buscar</button>
                </div>
                <div class="col-100">
                    <label for="imagen">Imagen:</label><br>
                    <input type="file" id="imagen" name="imagen" accept="image/*" required><br><br>
                </div>
                <div class="col-100">
                    <button type="submit">Publicar Reporte</button>
                </div>
            
            </fieldset> 
        </form>
    </div>

    <h1>Reportes Ciudadanos</h1>
    <p>Reporta problemas en tu comunidad y ayuda a solucionarlos.</p>
    
    <h2><center>Lista de Reportes</center></h2>

    <div class="container1">
        <form method="GET">

            <fieldset>
                <!-- <legend>Datos personales</legend> -->
                <div class="col-100">
                    <label for="Buscador">Buscador</label>
                    <input type="text" id="FiltrarContenido" name="Buscador" placeholder=" consultar reporte">
                    <button type="submit">Consultar</button>
                </div>

                <div class="col-100">
                    <h2>Ordenar Por:</h2>
                    <label for="categoria">Categoría:</label>
                    <select name="categoria">
                        <option value="">Todas</option>
                        <option value="Seguridad">Seguridad</option>
                        <option value="Emergencias">Emergencias</option>
                        <option value="Infraestructura">Infraestructura</option>
                        <option value="salud">Salud</option>
                    </select>
                    <button type="submit">Filtrar</button>
                </div>
            </fieldset>
        <form>

        <form method="GET">
            <fieldset>
                <!-- <legend>Datos personales</legend> -->
                <div class="col-100">

                    <table>
                        <tr>
                            <th>Titulo</th>
                            <th>Descripcion</th>
                            <th>Categoria</th>
                            <th>Ubicacion</th>
                            <th>Imagen</th>
                            <th COLSPAN=2>Acciones</th>
                        </tr>
                        <tr>
                        <?php $i=0; foreach ($reportes as $reporte):?>
                            <tr>
                                <td><?php echo $reporte["titulo"]; ?></td>
                                <td><?php echo $reporte["descripcion"]; ?></td>
                                <td><?php echo $reporte["categoria"]; ?></td>
                                <td><?php echo $reporte["ubicacion"]; ?></td>
                                <td>
                                    <img src="<?php echo $imagenes[$i];?>" alt="Imagen Reporte" width="50" height="50">
                                </td>
                                <td>
                                    <button class="small" style="background-color: green;" onclick="alert('Reporte Actualizado')">UPDATE</button>
                                </td>
                                <td>
                                    <button class="small" style="background-color: red;" onclick="alert('Reporte')">DELETE</button>
                                </td>
                            </tr>
                        <?php $i++; endforeach; ?>
                        </tr>
                    </table>
                </div>
            </fieldset>
        </form>
        
        
    </div>
</body>
</html>