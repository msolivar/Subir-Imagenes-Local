<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="hojaEstilo.css">
    <title>Contacto</title>
</head>
<body>

    <?php  
        include('navPrincipal.php');
    ?>
    <div class="container">
        <h2><center>Contacto</center></h2>

        <form action="contactarAdministrador.php" method="POST" enctype="multipart/form-data">
            
            <fieldset>
                <!-- <legend>Datos personales</legend> -->
                <div class="col-100">
                    <label for="nombre">Nombre completo:</label><br>
                    <input type="text" id="nombre" name="nombre" placeholder=" Ingrese el nombre" required><br>
                </div>
                <div class="col-100">
                    <label for="email">Correo electrónico:</label><br>
                    <input type="email" id="email" name="email" placeholder=" Ingrese el correo" required><br>
                </div>
                <div class="col-100">
                    <label for="categoria">Categoría:</label><br>
                    <select id="categoria" name="categoria" required>
                        <option value="" disabled selected>Seleccione la categoria</option>
                        <option value="seguridad">Seguridad</option>
                        <option value="salud">Salud</option>
                    </select><br>
                </div>
                <div class="col-100">
                    <label for="mensaje">Mensaje:</label><br>
                    <textarea id="mensaje" name="mensaje" placeholder="Ingrese el mensaje" required></textarea><br>
                </div>
                <div class="col-100">
                    <button type="submit">Enviar</button>
                </div>
            
            </fieldset> 
        </form>
    </div>
</body>
</html>