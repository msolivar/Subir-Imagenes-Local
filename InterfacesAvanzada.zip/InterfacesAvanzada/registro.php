<?php
    $ciudad= array("1" => "Armenia","2" => "Pereira");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="hojaEstilo.css">
    <title>Registro de Usuario</title>
</head>
<body>
    
    <?php  
        include('navPrincipal.php');
    ?>

    <div class="container">
        <h2><center>Crear una Cuenta</center></h2>
        
        <form action="guardarRegistro.php" method="POST">

            <fieldset>
                <!-- <legend>Datos personales</legend> -->
                <div class="col-100">
                    <label for="nombre">Nombre completo:</label><br>
                    <input type="text" id="nombre" name="nombre" placeholder=" Ingrese el nombre" required><br>
                </div>
                <div class="col-100">
                    <label for="ciudad">Ciudad:</label><br>
                    <select name="ciudad" id=ciudad" required>
                        <option value="" disabled selected>Seleccione la ciudad</option>
                        <option value="<?=$ciudad['1']?>"><?=$ciudad['1']?></option>
                        <option value="<?=$ciudad['2']?>"><?=$ciudad['2']?></option>
                    </select>
                </div>
                <div class="col-100">
                    <label for="telefono">Teléfono:</label><br>
                    <input type="text" id="telefono" name="telefono" placeholder=" Ingrese el telefono" required><br>
                </div>
                <div class="col-100">
                    <label for="direccion">Dirección:</label><br>
                    <input type="text" id="direccion" name="direccion" placeholder=" Ingrese la direccion" required><br>
                </div>
                <div class="col-100">
                    <label for="email">Correo electrónico:</label><br>
                    <input type="email" id="email" name="email" placeholder=" Ingrese el correo" required><br>
                </div>
                <div class="col-100">
                    <label for="password">Contraseña:</label><br>
                    <input type="password" id="password" name="password" placeholder=" Ingrese la contraseña" minlength="8" required><br><br>
                </div>
                <div class="col-100">
                    <button type="submit" title="Por favor Diligencia el formulario">Registrar Cuenta</button>
                </div>

                <div class="col-100">
                    <center>
                        <p>¿Ya tienes una cuenta? 
                            <a style="color:blue;" href="login.php" title="Inicia sesión">Inicia sesión</a>
                        </p>
                    </center>
                </div>
                <label>
                    <a href="index.php">Volver</a>
                </label>
            </fieldset>
           
        </form>
    </div>
</body>
</html>