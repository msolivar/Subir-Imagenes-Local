<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="hojaEstilo.css">
    <title>Restablecer Contraseña</title>
</head>
<body>
    <div class="container">
        <h2><center>Activar Cuenta</center></h2>
        <form id="restablecerForm">
            <fieldset>
            <!-- <legend>Datos personales</legend> -->
                <p>Hemos enviado al correo el codigo de activacion dispone de 15 minutos para poder activar su cuenta ingrese el codigo</p>
                <div class="col-100">
                    <label for="codigo">Código De Activacion:</label>
                    <input type="text" id="codigo" name="codigo" required placeholder="Ingrese el código de Activacion">
                </div>
                <div class="col-100">
                    <button type="submit">Enviar</button>
                </div>
            </fieldset>
        </form>
    </div>

    <script>
        document.getElementById('restablecerForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Evitar el envío del formulario

            const codigo = document.getElementById('codigo').value.trim();
            const nuevaContraseña = document.getElementById('nuevaContraseña').value.trim();
            const codigoError = document.getElementById('codigoError');
            const contraseñaError = document.getElementById('contraseñaError');

            // Limpiar mensajes de error previos
            codigoError.textContent = '';
            contraseñaError.textContent = '';

            // Validar código de recuperación
            if (!codigo) {
                codigoError.textContent = 'El código de recuperación es obligatorio.';
                return;
            }

            // Validar nueva contraseña
            if (!nuevaContraseña) {
                contraseñaError.textContent = 'La nueva contraseña es obligatoria.';
                return;
            }

            const contraseñaRegex = /^(?=.*[a-z])(?=.*\d).{8,}$/;
            if (!contraseñaRegex.test(nuevaContraseña) ) {
                contraseñaError.textContent = 'La contraseña debe tener al menos 8 caracteres, minúsculas y números';
                return;
            }

            // Simular actualización de la contraseña (puedes reemplazar esto con una llamada AJAX)
            alert('Contraseña actualizada exitosamente.');
            window.location='codigoDeActivacion.php';
        });
    </script>
</body>
</html>