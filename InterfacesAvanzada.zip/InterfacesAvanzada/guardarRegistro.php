<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $ciudad = $_POST['ciudad'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validaciones básicas
    if (empty($nombre) || empty($ciudad) || empty($telefono) || empty($direccion) || empty($email) || empty($password)) {
        echo "Todos los campos son obligatorios.";
        exit;
    }
    if (strlen($password) < 8) {
        echo "La contraseña debe tener al menos 8 caracteres.";
        exit;
    }

    // Simulación de envío de código de activación
    echo '<script type="text/javascript">
			alert("Registro exitoso.\n Se ha enviado un codigo de activacion a su correo.");     
			window.location="index.php";
		</script>';
}
?>