<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titulo = $_POST['titulo'];
    $categoria = $_POST['categoria'];
    $descripcion = $_POST['descripcion'];
    $imagen = $_FILES['imagen'];

    // Validaciones básicas
    if (empty($titulo) || empty($categoria) || empty($descripcion) || empty($imagen['name'])) {
        echo "Todos los campos son obligatorios.";
        exit;
    }

    // Validación de formato y tamaño de imagen
    $allowed_types = ['image/jpeg', 'image/png'];
    if (!in_array($imagen['type'], $allowed_types)) {
        echo "Formato de imagen no permitido.";
        exit;
    }
    if ($imagen['size'] > 2 * 1024 * 1024) { // 2MB
        echo "La imagen no debe superar 2MB.";
        exit;
    }

    echo "Reporte publicado correctamente.";
}
?>