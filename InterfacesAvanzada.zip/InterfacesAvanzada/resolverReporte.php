<?php
echo '<script type="text/javascript">
    alert("El reporte ha sido marcado como resuelto.");     
    window.location="estadoReporte.php";
</script>';
?>