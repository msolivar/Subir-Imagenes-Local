<?php
echo "¿Está seguro de eliminar su cuenta? Esta acción es irreversible.";
?>