<?php
$estado = $_GET['estado'] ?? '';

// Simulación de reportes del usuario
$reportes = [
    ["id" => 1, "titulo" => "Problema de seguridad", "estado" => "pendiente"],
];

foreach ($reportes as $reporte) {
    if ($estado === '' || $reporte['estado'] === $estado) {
        echo "<li>{$reporte['titulo']} - <a href='detalle_reporte.php?id={$reporte['id']}'>Ver detalles</a></li>";
    }
}
?>