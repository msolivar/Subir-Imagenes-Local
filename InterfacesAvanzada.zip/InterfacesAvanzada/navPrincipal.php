<header>
    <a style="text-decoration: none; color: inherit; font-weight: bold;" href="index.php" title="Reportes Ciudadanos">Reportes Ciudadanos</a>
</header>
<nav>
    <a href="reportes.php">Reportes</a>
    <a href="destacados.php">Destacados</a>
    <a href="contacto.php">Contacto</a>
    <a href="login.php">Iniciar Sesión</a>
    <a href="registro.php">Registro</a>
</nav>
<br>