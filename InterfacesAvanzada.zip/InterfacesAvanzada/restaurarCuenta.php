<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="hojaEstilo.css">
    <title>Restablecer Contraseña</title>
</head>
<body>

    <?php  
        include('navPrincipal.php');
    ?>
    <div class="container">
        <h2><center>Restablecer Contraseña</center></h2>
        <form id="restablecerForm">
            <fieldset>
            <p>Hemos enviado al correo el codigo de activacion dispone de 15 minutos para poder activar su cuenta ingrese el codigo</p>
            <!-- <legend>Datos personales</legend> -->
                <div class="col-100">
                    <label for="codigo">Código De Recuperación:</label>
                    <input type="text" id="codigo" name="codigo" required placeholder="Ingrese el código">
                </div>
                <div class="col-100">
                    <span id="codigoError" class="error"></span>
                </div>
                <!-- <div class="col-100">
                    <label for="nuevaContraseña">Nueva Contraseña:</label>
                    <input type="password" id="nuevaContraseña" name="nuevaContraseña" required placeholder="Ingrese la nueva contraseña">
                </div>
                <div class="col-100">
                    <span id="contraseñaError" class="error"></span>
                </div> -->
                <div class="col-100">
                    <button type="submit">Restaurar Cuenta</button>
                </div>
                <label>
                    <a href="index.php">Volver</a>
                </label>
            </fieldset>
        </form>
    </div>

    <script>
        document.getElementById('restablecerForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Evitar el envío del formulario

            const codigo = document.getElementById('codigo').value.trim();
            // const nuevaContraseña = document.getElementById('nuevaContraseña').value.trim();
            // const codigoError = document.getElementById('codigoError');
            // const contraseñaError = document.getElementById('contraseñaError');

            // Limpiar mensajes de error previos
            codigoError.textContent = '';
            // contraseñaError.textContent = '';

            // Validar código de recuperación
            if (!codigo) {
                codigoError.textContent = 'El código de recuperación es obligatorio.';
                return;
            }

            // // Validar nueva contraseña
            // if (!nuevaContraseña) {
            //     contraseñaError.textContent = 'La nueva contraseña es obligatoria.';
            //     return;
            // }

            // const contraseñaRegex = /^(?=.*[a-z])(?=.*\d).{8,}$/;
            // if (!contraseñaRegex.test(nuevaContraseña) ) {
            //     contraseñaError.textContent = 'La contraseña debe tener al menos 8 caracteres, minúsculas y números';
            //     return;
            // }

            // Simular actualización de la contraseña (puedes reemplazar esto con una llamada AJAX)
            alert('Contraseña actualizada exitosamente.');
            window.location='login.php';
        });
    </script>
</body>
</html>