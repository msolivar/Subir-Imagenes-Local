<?php
$sector = $_POST['sector'];
$categoria = $_POST['categoria'];
$fecha_inicio = $_POST['fecha_inicio'];
$fecha_fin = $_POST['fecha_fin'];

// Simulación de generación de informe
echo "Informe generado para el sector '{$sector}' en la categoría '{$categoria}' desde '{$fecha_inicio}' hasta '{$fecha_fin}'.";
?>