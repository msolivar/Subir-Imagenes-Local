<?php
// Simulación de notificaciones
$notificaciones = [
    ["id" => 1, "mensaje" => "Reporte #1: Problema de seguridad"],
    ["id" => 2, "mensaje" => "Reporte #2: Accidente de tráfico"],
];

foreach ($notificaciones as $notificacion) {
    echo "<li><a href='detalle_reporte.php?id={$notificacion['id']}'>{$notificacion['mensaje']}</a></li>";
}
?>