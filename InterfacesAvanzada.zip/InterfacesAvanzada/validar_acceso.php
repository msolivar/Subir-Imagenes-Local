<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario'])) {
    header("Location: login.html");
    exit;
}

// Verificar el rol del usuario
$rol = $_SESSION['rol'] ?? 'cliente';

// Función para validar acceso según rol
function validarAcceso($rolPermitido) {
    global $rol;
    if ($rol !== $rolPermitido) {
        echo "No tienes permiso para acceder a esta página.";
        exit;
    }
}
?>