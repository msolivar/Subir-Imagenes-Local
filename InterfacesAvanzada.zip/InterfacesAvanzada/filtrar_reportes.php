<?php
$estado = $_GET['estado'] ?? '';

// Simulación de lista de reportes
$reportes = [
    ["id" => 1, "titulo" => "Problema de seguridad", "estado" => "pendiente"],
    ["id" => 2, "titulo" => "Accidente de tráfico", "estado" => "verificado"],
];

echo "<h3>Resultados:</h3>";
foreach ($reportes as $reporte) {
    if ($estado === '' || $reporte['estado'] === $estado) {
        echo "<p>{$reporte['titulo']} - Estado: {$reporte['estado']}</p>";
    }
}
?>