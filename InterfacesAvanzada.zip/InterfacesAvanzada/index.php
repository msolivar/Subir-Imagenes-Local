<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="hojaEstilo.css">
    <title>Reportes Ciudadanos</title>
</head>
<body>
    
    <?php  
        include('navPrincipal.php');
    ?>
    <div class="container">
        <h2>Bienvenido al Sistema de Gestión de Eventos Ciudadanos</h2>
        <p>Seleccione una opción del menú para comenzar.</p>
    </div>
</body>
</html>