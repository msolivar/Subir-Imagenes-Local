<header>
    <a style="text-decoration: none; color: inherit; font-weight: bold;" href="index.php" title="Reportes Ciudadanos">Reportes Ciudadanos</a>
</header>
<nav>
    <a href="gestionarReporte.php">Gestionar Reportes</a>
    <a href="estadoReporte.php">Estado Reportes</a>
    <a href="contacto.php">Contacto1</a>
    <a href="login.php">Iniciar Sesión1</a>
    <a href="registro.php">Administrar Cuenta</a>
    <a href="index.php">Salir</a>
</nav>

<h1 class="usuario">Bienvenido Usuario</h1>
<br>