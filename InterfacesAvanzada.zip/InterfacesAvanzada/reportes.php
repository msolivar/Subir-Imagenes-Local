<?php
$reportes = [
    ["id" => 1, "categoria" => "Seguridad", "titulo" => "Robo en la esquina", "descripcion" => "Se reportó un robo cerca de la avenida principal.", "importancia" => 5],
    ["id" => 2, "categoria" => "Emergencias", "titulo" => "Accidente de tránsito", "descripcion" => "Choque entre dos vehículos en la intersección.", "importancia" => 3],
    ["id" => 3, "categoria" => "Infraestructura", "titulo" => "Farola rota", "descripcion" => "Farola sin luz en el parque central.", "importancia" => 2]
];

$imagenes = [
    'https://www.eluniversal.com.co/resizer/v2/FLNNWNEB3JH45JI2GANJKUHVNU.jpeg?auth=89a448ce92002d63fd62c9572197517045cf8672037cfa300359c0a4716d483d&smart=true&width=1200&height=800&quality=70',
    'https://i0.wp.com/nbi.com.co/wp-content/uploads/2020/10/accidente-de-transito-articulo-e1721281923171.jpg?fit=1199%2C627&ssl=1',
    'https://media.istockphoto.com/id/496026170/es/foto/broken-street-l%C3%A1mpara.jpg?s=1024x1024&w=is&k=20&c=ExTrjvvsx-lYoNozjaw22EwPlJMBWq294Kh-PDs8hO4=',
    'https://i0.wp.com/nbi.com.co/wp-content/uploads/2020/10/accidente-de-transito-articulo-e1721281923171.jpg?fit=1199%2C627&ssl=1'
];

function filtrarReportes($categoria, $reportes) {
    return array_filter($reportes, function($reporte) use ($categoria) {
        return $reporte["categoria"] == $categoria;
    });
}

if (isset($_GET["categoria"])) {
    $categoria = $_GET["categoria"];
    $reportes = filtrarReportes($categoria, $reportes);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="hojaEstilo.css">
    <title>Reportes Ciudadanos</title>
</head>
<body>

    <?php  
        include('navPrincipal.php');
    ?>

    <h2 style="color:red;"><center>Lista de Reportes</center></h2>
    <h2 style="color:green;"><center>En este apartado va el mapa</center></h2>
    <form action="filtrar_reportes.php" method="GET">
        <label for="estado">Filtrar por estado:</label>
        <select id="estado" name="estado">
            <option value="pendiente">Pendiente</option>
            <option value="verificado">Verificado</option>
        </select>
        <button type="submit">Aplicar Filtros</button>
    </form>

    <h1>Reportes Ciudadanos</h1>
    <p>Reporta problemas en tu comunidad y ayuda a solucionarlos.</p>
    
    <h2><center>Lista de Reportes</center></h2>

    <div class="container1">
        <form method="Post">

            <fieldset>
                <!-- <legend>Datos personales</legend> -->
                <div class="col-100">
                    <label for="Buscador">Buscador</label>
                    <input type="text" id="FiltrarContenido" name="Buscador" placeholder=" consultar reporte">
                    <button type="submit">Consultar</button>
                </div>

                <div class="col-100">
                    <h2>Ordenar Por:</h2>
                    <label for="categoria">Categoría:</label>
                    <select name="categoria">
                        <option value="">Todas</option>
                        <option value="Seguridad">Seguridad</option>
                        <option value="Emergencias">Emergencias</option>
                        <option value="Infraestructura">Infraestructura</option>
                        <option value="salud">Salud</option>
                    </select>
                    <button type="submit">Filtrar</button>
                </div>
            </fieldset>
        <form>

        <form method="GET">
            <fieldset>
                <!-- <legend>Datos personales</legend> -->
                <div class="col-100">
                
                    <table>
                        <tr>
                        <?php $i=0; foreach ($reportes as $reporte):?>
                            <td>
                                <img src="<?php echo $imagenes[$i];?>" alt="Imagen Reporte" width="250" height="200">
                                <h3><?php echo $reporte["titulo"]; ?></h3>
                                <p><?php echo $reporte["descripcion"]; ?></p>
                                <p><strong>Categoría:</strong> <?php echo $reporte["categoria"]; ?></p>
                                <p><strong>Importancia:</strong> <?php echo $reporte["importancia"]; ?></p>

                                <h1 class="color:red;">Agregar Ventan Emergente Comentarios</h1>
                                <button onclick="alert('¡Has marcado este reporte como importante!')">Es importante</button>
                                <button onclick="alert('Esto hace que la zona sea insegura\n -->Agregar Comentario<--')">Comentarios</button>
                            </td>
                        <?php $i++; endforeach; ?>
                        </tr>
                    </table>
                </div>
            </fieldset>
        </form>
        
        
    </div>
</body>
</html>