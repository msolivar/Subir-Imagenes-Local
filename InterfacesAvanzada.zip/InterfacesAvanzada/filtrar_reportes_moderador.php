<?php
$categoria = $_GET['categoria'] ?? '';

// Simulación de reportes pendientes
$reportes = [
    ["id" => 1, "titulo" => "Problema de seguridad", "categoria" => "seguridad"],
];

foreach ($reportes as $reporte) {
    if ($categoria === '' || $reporte['categoria'] === $categoria) {
        echo "<li>{$reporte['titulo']} - <a href='moderador_detalle_reporte.php?id={$reporte['id']}'>Ver detalles</a></li>";
    }
}
?>