<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Simulación de credenciales válidas
    $usuario_valido = "us1@email.com";
    $contrasena_valida = "12341234";

    if ($email === $usuario_valido && $password === $contrasena_valida) {
      echo '<script type="text/javascript">
			  alert("Bienvenido: '.$email.'");     
			  window.location="gestionarReporte.php";
		  </script>';
    } else {
      echo '<script type="text/javascript">
			  alert("Credenciales incorrectas.");     
			  window.location="login.php";
		  </script>';
    }
}
?>