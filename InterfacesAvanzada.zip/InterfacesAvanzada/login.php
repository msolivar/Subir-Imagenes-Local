<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="hojaEstilo.css">
    <title>Iniciar Sesión</title>
</head>
<body>
    <!--Import jQuery before materialize.js-->
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  
    <!-- js para mostrar la contraseña -->
    <script type="text/javascript" src="mostrarPassword.js"></script>

    <?php  
        include('navPrincipal.php');
    ?>
    
    <div class="container">
        <h2><center>Iniciar Sesión</center></h2>

        <form action="validarLogin.php" method="POST">

            <fieldset>
                <!-- <legend>Datos personales</legend> -->
                <div class="col-100">
                    <label for="email">Correo electrónico:</label><br>
                    <input type="email" id="email" name="email" placeholder=" Ingrese el correo" required><br>
                </div>
                <div class="col-100">
                    <label for="password">Contraseña:</label><br>
                    <input type="password" id="password" name="password" placeholder=" Ingrese la contraseña" minlength="8" required><br>
                </div>
                <div class="col-100">
                    <input type="checkbox" id="VerPassword" name="VerPassword">
                    <label class="blanco" for="VerPassword">Ver contraseña</label>
                    <br><br>
                </div>
                
                <button type="submit">Iniciar sesión</button>

                <div class="col-100">

                    <label>
                        <a href="restaurarCuenta.php">Olvido su Contraseña</a>
                    </label>
                    <center>
                        <p>¡No tienes cuenta!
                            <a style="color:blue;" href="registro.php" title="Regístrate">Regístrate</a>
                        </p>
                    </center>
                </div>
                <label>
                    <a href="index.php">Volver</a>
                </label>
            </fieldset>
        </form>
    </div>
</body>
</html>