<?php
$formato = $_POST['formato'] ?? '';

if ($formato === 'pdf') {
    echo "Exportando reportes en formato PDF...";
} elseif ($formato === 'csv') {
    echo "Exportando reportes en formato CSV...";
}
?>