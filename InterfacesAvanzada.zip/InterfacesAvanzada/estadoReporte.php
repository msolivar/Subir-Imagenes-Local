<?php
    // include 'validar_acceso.php';

    // Solo los clientes pueden acceder a esta página
    // validarAcceso('cliente');

    // Simulación de lista de reportes del usuario
    $reportes = [
        ["id" => 1, "titulo" => "Problema de seguridad", "estado" => "pendiente"],
        ["id" => 2, "titulo" => "Daño Alumbrado ", "estado" => "aprobado"]
    ];

    echo "<h2>Reportes Verificados</h2>";
    foreach ($reportes as $reporte) {
        echo "<p>{$reporte['titulo']} - Estado: {$reporte['estado']}</p>";
    }
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Reportes</title>
</head>
<body>
    <h2>Mis Reportes</h2>
    <form action="filtrar_mis_reportes.php" method="GET">
        <label for="estado">Filtrar por estado:</label>
        <select id="estado" name="estado">
            <option value="pendiente">Pendiente</option>
            <option value="verificado">Verificado</option>
            <option value="resuelto">Resuelto</option>
        </select>
        <button type="submit">Filtrar</button>

        <h1>
            <a style="color:red;" href="resolverReporte.php">Aprobar Reporte</a>
        </h1>
    </form>

    <h1>Reportes Rechazados:</h1>
    <ul>
        <li>Reporte #1: Problema de seguridad - <a href="detalle_reporte.php?id=1">Ver detalles</a></li>
    </ul>
</body>
</html>