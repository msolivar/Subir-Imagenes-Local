<?php
$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];

// Simulación de guardado
echo "Cambios guardados correctamente.";
?>