<?php
include 'validar_acceso.php';

// Solo los moderadores pueden acceder a esta página
validarAcceso('moderador');

// Simulación de lista de reportes pendientes
$reportes = [
    ["id" => 1, "titulo" => "Problema de seguridad", "estado" => "pendiente"],
];

echo "<h2>Reportes Pendientes</h2>";
foreach ($reportes as $reporte) {
    echo "<p>{$reporte['titulo']} - Estado: {$reporte['estado']}</p>";
}
?>